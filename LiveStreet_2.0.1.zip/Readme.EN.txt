LiveStreet 2.0.1

Free social engine.

INSTALLATION
1. Copy files to the engine to the desired directory site
2. Go the address http://you_site/
3. Follow the instructions of the installer.