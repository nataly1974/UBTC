lsplugin-admin
==============
