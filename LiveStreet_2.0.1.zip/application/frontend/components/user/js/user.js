/**
 * Управление пользователями
 *
 * @module ls/user
 *
 * @license   GNU General Public License, version 2
 * @copyright 2013 OOO "ЛС-СОФТ" {@link http://livestreetcms.com}
 * @author    Denis Shakhov <denis.shakhov@gmail.com>
 */

var ls = ls || {};

ls.user = (function ($) {
    "use strict";

    this.init = function () {
        return;
    };

    return this;
}).call(ls.user || {}, jQuery);