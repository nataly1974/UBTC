<?php

return [
    'synio' => [
        'guest' => 'Guest',
        'site_pages' => 'Pages',
        'drafts' => '%%count%% draft;%%count%% drafts;%%count%% drafts',
        'user_about_empty' => 'No data yet...',
        'all_blogs' => 'All blogs'
    ],
    'activity' => [
        'block_recent' => [
            'all' => 'All activities'
        ]
    ],
    'user' => [
        'search' => [
            'title' => 'Search'
        ]
    ]
];