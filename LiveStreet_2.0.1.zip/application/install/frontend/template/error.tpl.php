<div class="alert alert--error">
    Ошибка: <?php echo $this->get('msg'); ?>
</div>