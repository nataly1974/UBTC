<div class="complete">
    <p>
        Теперь обязательно удалите каталог <b>/application/install/</b> и можете <a href="<?php echo InstallConfig::get('path.root.web'); ?>">перейти на сайт</a>.
        <br/>
        Приятного использования новой версией LiveStreet!
    </p>
</div>