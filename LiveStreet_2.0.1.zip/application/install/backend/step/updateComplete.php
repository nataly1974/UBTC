<?php

class InstallStepUpdateComplete extends InstallStepInstallComplete
{

}